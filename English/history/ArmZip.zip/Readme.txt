                   Games Workshop's
		Battle for Armageddon
	
		  Setup Instructions


Thanks for downloading Battle for Armageddon. Apart from
this zip file all you will need to play the game is a couple
of dice, some stiff card and a colour printer.

The Zip file should contain 28 files:

This Readme.txt file

Armageddon Rules.pdf

Game Board:	board1.jpg
		board2.jpg
		board3.jpg
		board4.jpg
		board5.jpg	
		board6.jpg

Game Pieces:	sheet1a.jpg	-	Ork game pieces, side a
		sheet1b.jpg	-	Ork game pieces, side b 
		sheet2a.jpg	-	Imperial game pieces, side a
		sheet2b.jpg	-	Imperial game pieces, side b
		sheet3aimp.jpg	-	Imperial Special Cards, side a
		sheet3aork.jpg	-	Ork Special Cards, side b
		sheet3bimp.jpg	-	Imperial Special Cards, side a
		sheet3bork.jpg	-	Ork Special Cards, side a
		sheet4a.jpg	-	Imperial and City counters, side a
		sheet4b.jpg	-	Imperial and City counters, side b
		sheet5a.jpg	-	Strategy Cards, side a
		sheet5b.jpg	-	Strategy Cards, side b
		sheet6a.jpg	-	Quick Reference card, side a
		sheet6b.jpg	-	Quick Reference card, side b


The pieces of the game and the board are in jpeg format, 
while the rules are in in Adobe Acrobat PDF format. 
If you do not have an Acrobat Reader, you can download 
one for free from www.adobe.com. 
You also must have a reasonably good image manipulation program,
eg Paint Shop Pro or PhotoShop (Paint Shop Pro can be downloaded
for free from www.jasc.com). Microsoft Paint will NOT work,
and printing the images from the Browser will NOT work. These 
applications do not have proper image control so the images
will print at the wrong size.

To make the pieces simply print all of the images on separate
pieces of paper (we suggest using high quality paper) and glue
onto some stiff card, then cut out each piece, preferably with
a scalpel or craft knife. The a sides and b sides of each sheet must
be on opposite sides of the same piece of card, and care must be 
taken to make sure each side lines up correctly with the other.

To make the board, print out the board images and attach them to 
a large piece of card (or several smaller pieces). Some of the
peices will overlap so take care to line them up correctly.



All files Copyright Games Workshop Ltd 2000. These files should not
be redistributed without permission and their contents should not be altered.