                   Games Workshop's
		     Chaos Attack
	
		  Setup Instructions


Thanks for downloading Chaos Attack. You will need Games Workshop's
Battle for Armageddon to play this game. Apart from this zip file 
all you will need to play the game is a couple of dice, some 
stiff card and a colour printer.

The Zip file should contain 28 files:

This Readme.txt file

Chaos Attack Rules.pdf

Chaos Attack	chaosa.jpg	-	Chaos Strategy and Special cards, side a
Pieces:		chaosb.jpg	-	Chaos Strategy and Special cards, side b
		chaoscountera.jpg	Chaos and Ork game pieces, side a	
		chaoscounterb.jpg	Chaos and Ork game pieces, side b
		orkcountera.jpg	-	Ork and misc. game pieces, side a
		orkcounterb.jpg	-	Ork and misc. game pieces, side b


The pieces of the game and the board are in jpeg format, 
while the rules are in in Adobe Acrobat PDF format. 
If you do not have an Acrobat Reader, you can download 
one for free from www.adobe.com. 
You also must have a reasonably good image manipulation program,
eg Paint Shop Pro or PhotoShop (Paint Shop Pro can be downloaded
for free from www.jasc.com). Microsoft Paint will NOT work,
and printing the images from the Browser will NOT work. These 
applications do not have proper image control so the images
will print at the wrong size.

To make the pieces simply print all of the images on separate
pieces of paper (we suggest using high quality paper) and glue
onto some stiff card, then cut out each piece, preferably with
a scalpel or craft knife. The a sides and b sides of each sheet must
be on opposite sides of the same piece of card, and care must be 
taken to make sure each side lines up correctly with the other.

To make the board, print out the board images and attach them to 
a large piece of card (or several smaller pieces). Some of the
peices will overlap so take care to line them up correctly.



All files Copyright Games Workshop Ltd 2000. These files should not
be redistributed without permission and their contents should not be altered.